# These lists store the entire system data while the program runs
students = []
instructors = []
courses = []

